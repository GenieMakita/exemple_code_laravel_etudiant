    
    <?php $__env->startSection('content'); ?>
        <h1>A propos de nous</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
            Eveniet, expedita debitis animi voluptatibus sapiente nesciunt esse corporis magnam?
            Expedita placeat quos culpa fuga nulla, magni eveniet earum minima tempore eos.
        </p>

        <p> <a href="/">Retour acueil</a></p>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app-laravel\resources\views/apropos.blade.php ENDPATH**/ ?>