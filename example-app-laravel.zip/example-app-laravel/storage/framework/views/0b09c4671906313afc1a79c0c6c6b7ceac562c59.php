    <?php $__env->startSection('content'); ?>
        <h1>Formulaire d'inscription élève :</h1>
        <p>

        </p>

        <p> <a href="/">Retour acueil</a></p>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app-laravel\resources\views/inscription-eleve.blade.php ENDPATH**/ ?>