<?php $__env->startSection("maincontent"); ?>
            <div class="my-3 p-3 bg-body rounded shadow-sm">
                <h3 class="border-bottom pb-2 mb-4">Ajout nouvel Etudiant</h3>
                <div class="mt-2">
                    <?php if(session()->has("success")): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get("success")); ?>

                        </div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger">
                            <ul>
                                <li><?php echo e($error); ?></li>
                            </ul>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(route('student_create_store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="nom" class="form-label">Nom</label>
                            <input type="text" required class="form-control" id="nom" name="nom" placeholder="Entrer le nom">
                        </div>
                        <div class="mb-3">
                            <label for="prenom" class="form-label">Prenom</label>
                            <input type="text" required class="form-control" id="prenom" name="prenom" placeholder="Entrer le prenom">
                        </div>
                        <div class="mb-3">
                            <label for="classe" class="form-label">Classe</label>
                            <select class="form-select" required aria-label="Default select example" id="classe_id" name="classe_id">
                                <option selected disabled>Choisir ...</option>
                                <?php $__currentLoopData = $liste_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->libelle); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Enregistrer</button>
                            <a href="<?php echo e(route('students')); ?>" class="btn btn-secondary">Annuler</a>
                        </div>
                    </form>
                </div>
                <small class="d-block text-end mt-3">
                    <a href="<?php echo e(route('students')); ?>">Liste des étudiants</a>
                </small>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app-laravel\resources\views/etudiant_create.blade.php ENDPATH**/ ?>