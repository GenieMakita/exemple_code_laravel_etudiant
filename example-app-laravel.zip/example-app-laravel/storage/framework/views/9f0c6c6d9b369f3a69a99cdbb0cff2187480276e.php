<?php $__env->startSection("maincontent"); ?>
            <div class="my-3 p-3 bg-body rounded shadow-sm">
                <h3 class="border-bottom pb-2 mb-4">Liste des étudiants</h3>
                <div class="d-block text-end mb-3"><a href="<?php echo e(route('student_create')); ?>" class="btn btn-primary">Ajouter un nouvel etudiant</a></div>
                <div class="mt-2">
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Prénom</th>
                                <th scope="col">Classe</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $liste_etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                <td><?php echo e($etudiant->nom); ?></td>
                                <td><?php echo e($etudiant->prenom); ?></td>
                                <td><?php echo e($etudiant->classe->libelle); ?></td>
                                <td>
                                    <!-- <a href="#" class="btn btn-info">Editer</a> -->
                                    <a href="#" class="btn btn-danger" onclick="if(confirm('Voulez-vous supprimer cet étudiant : <?php echo e($etudiant->nom); ?> <?php echo e($etudiant->prenom); ?> ?')){
                                        alert('Patientez ...');
                                    }">Supprimer</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php echo e($liste_etudiants->links()); ?>

                    </table>
                </div>
                <small class="d-block text-end mt-3">
                    <a href="#">Tous les étudiants</a>
                </small>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app-laravel\resources\views/etudiant.blade.php ENDPATH**/ ?>