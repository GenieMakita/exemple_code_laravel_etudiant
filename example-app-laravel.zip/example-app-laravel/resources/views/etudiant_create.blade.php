@extends('layouts.master')

@section("maincontent")
            <div class="my-3 p-3 bg-body rounded shadow-sm">
                <h3 class="border-bottom pb-2 mb-4">Ajout nouvel Etudiant</h3>
                <div class="mt-2">
                    @if(session()->has("success"))
                        <div class="alert alert-success">
                            {{session()->get("success")}}
                        </div>
                    @endif
                    @foreach($errors->all() as $error)
                        <div class="alert alert-danger">
                            <ul>
                                <li>{{$error}}</li>
                            </ul>
                        </div>
                    @endforeach
                    <form action="{{route('student_create_store')}}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label for="nom" class="form-label">Nom</label>
                            <input type="text" required class="form-control" id="nom" name="nom" placeholder="Entrer le nom">
                        </div>
                        <div class="mb-3">
                            <label for="prenom" class="form-label">Prenom</label>
                            <input type="text" required class="form-control" id="prenom" name="prenom" placeholder="Entrer le prenom">
                        </div>
                        <div class="mb-3">
                            <label for="classe" class="form-label">Classe</label>
                            <select class="form-select" required aria-label="Default select example" id="classe_id" name="classe_id">
                                <option selected disabled>Choisir ...</option>
                                @foreach($liste_classes as $classe)
                                    <option value="{{$classe->id}}">{{$classe->libelle}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">Enregistrer</button>
                            <a href="{{route('students')}}" class="btn btn-secondary">Annuler</a>
                        </div>
                    </form>
                </div>
                <small class="d-block text-end mt-3">
                    <a href="{{route('students')}}">Liste des étudiants</a>
                </small>
            </div>
@endsection
