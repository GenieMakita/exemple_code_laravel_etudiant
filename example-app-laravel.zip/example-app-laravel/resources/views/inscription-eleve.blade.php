@extends('base')
    @section('content')
        <h1>Formulaire d'inscription élève :</h1>
        <p>

        </p>

        <p> <a href="/">Retour acueil</a></p>
    @endsection
