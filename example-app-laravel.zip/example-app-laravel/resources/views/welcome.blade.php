@extends('layouts.master')

@section("maincontent")
    <div class="my-3 p-3 bg-body rounded shadow-sm">
        <h3 class="border-bottom pb-2 mb-4">Bienvenue dans notre système d'inscription</h3>
    </div>
@endsection
