@extends('layouts.master')

@section("maincontent")
            <div class="my-3 p-3 bg-body rounded shadow-sm">
                <h3 class="border-bottom pb-2 mb-4">Liste des étudiants</h3>
                <div class="d-block text-end mb-3"><a href="{{route('student_create')}}" class="btn btn-primary">Ajouter un nouvel etudiant</a></div>
                <div class="mt-2">
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nom</th>
                                <th scope="col">Prénom</th>
                                <th scope="col">Classe</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($liste_etudiants as $etudiant)
                            <tr>
                                <th scope="row">{{$loop->index + 1}}</th>
                                <td>{{$etudiant->nom}}</td>
                                <td>{{$etudiant->prenom}}</td>
                                <td>{{$etudiant->classe->libelle}}</td>
                                <td>
                                    <!-- <a href="#" class="btn btn-info">Editer</a> -->
                                    <a href="#" class="btn btn-danger" onclick="if(confirm('Voulez-vous supprimer cet étudiant : {{$etudiant->nom}} {{$etudiant->prenom}} ?')){
                                        alert('Patientez ...');
                                    }">Supprimer</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                        {{$liste_etudiants->links()}}
                    </table>
                </div>
                <small class="d-block text-end mt-3">
                    <a href="#">Tous les étudiants</a>
                </small>
            </div>
@endsection
