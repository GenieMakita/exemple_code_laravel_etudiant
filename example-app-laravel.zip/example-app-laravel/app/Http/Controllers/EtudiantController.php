<?php

namespace App\Http\Controllers;

use App\Models\classe;
use App\Models\Etudiant;
use Illuminate\Http\Request;

class EtudiantController extends Controller
{
    //
    public function index(){
        $liste_etudiants = Etudiant::orderBy("nom", "asc")->paginate(5);
        return view("etudiant", [
            "liste_etudiants"=>$liste_etudiants
        ]);
    }

    public function create(){
        $liste_classes = classe::all();
        return view("etudiant_create", [
            "liste_classes"=>$liste_classes
        ]);
    }

    public function store(Request $request){
        $request->validate([
            "nom"=>"required",
            "prenom"=>"required",
            "classe_id"=>"required"
        ]);

        Etudiant::create([
            "nom"=>$request->nom,
            "prenom"=>$request->prenom,
            "classe_id"=>$request->classe_id
        ]);

        // $liste_classes = classe::all();
        return back()->with("success", "Etudiant enregistré avec succès !");
    }
}
