-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 02 déc. 2022 à 16:12
-- Version du serveur : 10.4.19-MariaDB
-- Version de PHP : 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `students_db_exemple`
--

-- --------------------------------------------------------

--
-- Structure de la table `classes`
--

CREATE TABLE `classes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `libelle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `classes`
--

INSERT INTO `classes` (`id`, `libelle`, `created_at`, `updated_at`) VALUES
(1, '1ère', '2022-12-01 22:41:19', NULL),
(2, '2ème', '2022-12-01 22:41:19', NULL),
(3, '3ème', '2022-12-01 22:42:19', NULL),
(4, '4ème', '2022-12-01 22:42:19', NULL),
(5, '5ème', '2022-12-01 22:42:54', NULL),
(6, '6ème', '2022-12-01 22:43:08', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `etudiants`
--

CREATE TABLE `etudiants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classe_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `etudiants`
--

INSERT INTO `etudiants` (`id`, `nom`, `prenom`, `classe_id`, `created_at`, `updated_at`) VALUES
(1, 'Smith', 'Amely', 2, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(2, 'Lebsack', 'Margarete', 1, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(3, 'Hettinger', 'Vicente', 2, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(4, 'Crist', 'Wilfredo', 3, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(5, 'Bartell', 'Austen', 4, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(6, 'Gutmann', 'Stevie', 2, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(7, 'Carter', 'Carmella', 2, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(8, 'Hessel', 'Nicklaus', 5, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(9, 'Veum', 'Ransom', 2, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(10, 'Pfannerstill', 'Bert', 4, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(11, 'Bosco', 'Henriette', 6, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(12, 'Roberts', 'Jayce', 6, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(13, 'O\'Kon', 'Coralie', 4, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(14, 'Crona', 'Tommie', 3, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(15, 'Smith', 'Isobel', 4, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(16, 'Muller', 'Oran', 5, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(17, 'Ondricka', 'Mateo', 2, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(18, 'King', 'Blanche', 3, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(19, 'Torp', 'Hosea', 3, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(20, 'Hauck', 'Cayla', 3, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(21, 'Bins', 'Laila', 6, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(22, 'Feest', 'Kiel', 4, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(23, 'Toy', 'Grayson', 3, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(24, 'Hammes', 'Zetta', 3, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(25, 'Conn', 'Sophia', 5, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(26, 'Walker', 'Tabitha', 2, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(27, 'Moen', 'Jason', 1, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(28, 'Monahan', 'Clifford', 5, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(29, 'Boyer', 'Jessy', 6, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(30, 'Von', 'Murl', 2, '2022-12-01 22:45:26', '2022-12-01 22:45:26'),
(31, 'luta', 'appie', 3, '2022-12-02 13:22:18', '2022-12-02 13:22:18'),
(32, 'makita', 'jayden', 2, '2022-12-02 13:37:00', '2022-12-02 13:37:00'),
(33, 'mak', 'genie', 1, '2022-12-02 13:40:33', '2022-12-02 13:40:33');

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_12_01_175548_create_classes_table', 1),
(6, '2022_12_01_175627_create_etudiants_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `etudiants`
--
ALTER TABLE `etudiants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `etudiants_classe_id_foreign` (`classe_id`);

--
-- Index pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Index pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `etudiants`
--
ALTER TABLE `etudiants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `etudiants`
--
ALTER TABLE `etudiants`
  ADD CONSTRAINT `etudiants_classe_id_foreign` FOREIGN KEY (`classe_id`) REFERENCES `classes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
